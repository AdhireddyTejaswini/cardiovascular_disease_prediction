const express = require("express");
const router = express.Router();
const HealthData = require("../models/HealthData");

// POST: Save Sensor Data
router.post("/add", async (req, res) => {
  try {
    const { heartRate, respiratoryRate } = req.body;

    // Validation (IMPORTANT)
    if (!heartRate || !respiratoryRate) {
      return res.status(400).json({
        error: "Heart rate and respiratory rate are required",
      });
    }

    let status = "Normal";

    if (heartRate > 100 || respiratoryRate > 25) {
      status = "High Risk";
    } else if (heartRate < 60 || respiratoryRate < 12) {
      status = "Low Risk";
    }

    const newData = new HealthData({
      heartRate,
      respiratoryRate,
      status,
    });

    await newData.save();

    res.json({
      message: "Data saved successfully",
      data: newData,
    });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET: Fetch all data
router.get("/", async (req, res) => {
  try {
    const data = await HealthData.find().sort({ createdAt: -1 });
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;