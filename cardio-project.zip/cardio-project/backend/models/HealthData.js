const mongoose = require("mongoose");

const healthDataSchema = new mongoose.Schema({
  heartRate: {
    type: Number,
    required: true,
  },
  respiratoryRate: {
    type: Number,
    required: true,
  },
  status: {
    type: String,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model("HealthData", healthDataSchema);