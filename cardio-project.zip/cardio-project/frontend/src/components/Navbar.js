import React from "react";
import { Link } from "react-router-dom";

function Navbar() {
  return (
    <div style={styles.nav}>
      <div style={styles.brand}>
        <span style={styles.icon}>❤️</span>
        <h3 style={styles.title}>CardioMonitor</h3>
      </div>

      <div style={styles.links}>
        <Link to="/dashboard" style={styles.link}>📊 Dashboard</Link>
        <Link to="/graph" style={styles.link}>📈 Graph</Link>
        <Link to="/attention" style={styles.link}>🚨 Alerts</Link>
        <Link to="/" style={styles.link}>🚪 Logout</Link>
      </div>
    </div>
  );
}

const styles = {
  nav: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    background: "linear-gradient(135deg, #0066cc 0%, #00d4ff 100%)",
    color: "white",
    padding: "16px 32px",
    boxShadow: "0 4px 12px rgba(0, 102, 204, 0.2)",
    position: "sticky",
    top: 0,
    zIndex: 100,
  },
  brand: {
    display: "flex",
    alignItems: "center",
    gap: "12px",
  },
  icon: {
    fontSize: "28px",
  },
  title: {
    margin: 0,
    fontSize: "24px",
    fontWeight: "700",
    letterSpacing: "0.5px",
  },
  links: {
    display: "flex",
    gap: "28px",
    alignItems: "center",
  },
  link: {
    color: "white",
    textDecoration: "none",
    fontSize: "15px",
    fontWeight: "500",
    transition: "all 0.3s ease",
    padding: "8px 12px",
    borderRadius: "6px",
    display: "inline-flex",
    alignItems: "center",
    gap: "6px",
  },
  "@media (max-width: 768px)": {
    nav: {
      padding: "12px 16px",
      flexDirection: "column",
      gap: "12px",
    },
    links: {
      gap: "12px",
      fontSize: "13px",
    },
  },
};

// Add hover effect dynamically
const style = document.createElement("style");
style.textContent = `
  a {
    transition: all 0.3s ease;
  }
  a:hover {
    background-color: rgba(255, 255, 255, 0.2);
    transform: translateY(-2px);
  }
`;
document.head.appendChild(style);

export default Navbar;