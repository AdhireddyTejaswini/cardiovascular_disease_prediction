import React, { useEffect, useState } from "react";
import axios from "axios";
import Navbar from "../components/Navbar";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

function Graph() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/health");
      setData(res.data.slice(0, 20).reverse());
      setLoading(false);
    } catch (err) {
      console.log(err);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const chartData = {
    labels: data.map((item) =>
      new Date(item.createdAt).toLocaleTimeString()
    ),
    datasets: [
      {
        label: "Heart Rate (bpm)",
        data: data.map((item) => item.heartRate),
        borderColor: "#e74c3c",
        backgroundColor: "rgba(231, 76, 60, 0.1)",
        borderWidth: 3,
        tension: 0.4,
        fill: true,
        pointRadius: 5,
        pointBackgroundColor: "#e74c3c",
        pointBorderColor: "white",
        pointBorderWidth: 2,
        pointHoverRadius: 7,
      },
      {
        label: "Respiratory Rate (/min)",
        data: data.map((item) => item.respiratoryRate),
        borderColor: "#0066cc",
        backgroundColor: "rgba(0, 102, 204, 0.1)",
        borderWidth: 3,
        tension: 0.4,
        fill: true,
        pointRadius: 5,
        pointBackgroundColor: "#0066cc",
        pointBorderColor: "white",
        pointBorderWidth: 2,
        pointHoverRadius: 7,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: true,
    plugins: {
      legend: {
        display: true,
        position: "top",
        labels: {
          font: {
            size: 14,
            weight: "600",
          },
          padding: 20,
          usePointStyle: true,
        },
      },
      title: {
        display: false,
      },
      tooltip: {
        backgroundColor: "rgba(0, 0, 0, 0.8)",
        padding: 12,
        titleFont: {
          size: 14,
          weight: "600",
        },
        bodyFont: {
          size: 13,
        },
        borderColor: "rgba(255, 255, 255, 0.2)",
        borderWidth: 1,
      },
    },
    scales: {
      y: {
        beginAtZero: false,
        grid: {
          color: "rgba(0, 0, 0, 0.05)",
        },
        ticks: {
          font: {
            size: 12,
          },
        },
      },
      x: {
        grid: {
          display: false,
        },
        ticks: {
          font: {
            size: 11,
          },
          maxRotation: 45,
          minRotation: 0,
        },
      },
    },
  };

  return (
    <div>
      <Navbar />

      <div style={styles.container}>
        <div style={styles.header}>
          <h1 style={styles.title}>📈 Health Data Analytics</h1>
          <p style={styles.subtitle}>Real-time visualization of your cardiovascular metrics</p>
        </div>

        {loading ? (
          <div style={styles.loadingState}>
            <p>Loading chart data...</p>
          </div>
        ) : data.length === 0 ? (
          <div style={styles.emptyState}>
            <p>No data available to display</p>
          </div>
        ) : (
          <div style={styles.chartCard}>
            <div style={styles.chartContainer}>
              <Line data={chartData} options={chartOptions} />
            </div>
          </div>
        )}

        <div style={styles.infoSection}>
          <div style={styles.infoCard}>
            <span style={styles.infoIcon}>❤️</span>
            <h3>Heart Rate</h3>
            <p>Normal: 60-100 bpm</p>
            <span style={styles.badge}>Normal Range</span>
          </div>
          
          <div style={styles.infoCard}>
            <span style={styles.infoIcon}>🌬️</span>
            <h3>Respiratory Rate</h3>
            <p>Normal: 12-25 /min</p>
            <span style={styles.badge}>Normal Range</span>
          </div>
          
          <div style={styles.infoCard}>
            <span style={styles.infoIcon}>⚠️</span>
            <h3>High Risk Alert</h3>
            <p>HR > 100 or RR > 25</p>
            <span style={{...styles.badge, background: "#e74c3c"}}>Alert</span>
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  container: {
    maxWidth: "1400px",
    margin: "0 auto",
    padding: "40px 20px",
  },
  header: {
    marginBottom: "40px",
    textAlign: "center",
  },
  title: {
    fontSize: "2.5rem",
    color: "#0066cc",
    marginBottom: "8px",
  },
  subtitle: {
    fontSize: "1.1rem",
    color: "#6c757d",
  },
  chartCard: {
    background: "white",
    borderRadius: "16px",
    padding: "32px",
    marginBottom: "40px",
    boxShadow: "0 8px 24px rgba(0, 0, 0, 0.1)",
    border: "2px solid #e0e0e0",
  },
  chartContainer: {
    position: "relative",
    height: "400px",
    width: "100%",
  },
  infoSection: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
    gap: "20px",
  },
  infoCard: {
    background: "white",
    borderRadius: "12px",
    padding: "24px",
    textAlign: "center",
    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.08)",
    border: "2px solid #e0e0e0",
    transition: "all 0.3s ease",
  },
  infoIcon: {
    fontSize: "40px",
    display: "block",
    marginBottom: "12px",
  },
  badge: {
    display: "inline-block",
    padding: "6px 16px",
    background: "#00b894",
    color: "white",
    borderRadius: "20px",
    fontSize: "0.85rem",
    fontWeight: "600",
    marginTop: "12px",
  },
  loadingState: {
    textAlign: "center",
    padding: "60px 20px",
    fontSize: "1.1rem",
    color: "#6c757d",
  },
  emptyState: {
    textAlign: "center",
    padding: "60px 20px",
    fontSize: "1.1rem",
    color: "#6c757d",
    background: "white",
    borderRadius: "12px",
  },
};

const animationStyles = `
  @media (max-width: 768px) {
    .title {
      font-size: 1.8rem;
    }
    
    .chart-container {
      height: 300px;
    }
    
    .info-section {
      grid-template-columns: 1fr;
    }
  }

  .info-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 12px 28px rgba(0, 102, 204, 0.15);
  }
`;

const styleSheet = document.createElement("style");
styleSheet.textContent = animationStyles;
document.head.appendChild(styleSheet);

export default Graph;