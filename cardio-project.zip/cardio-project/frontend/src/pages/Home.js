import React from "react";
import { Link } from "react-router-dom";

function Home() {
  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <div style={styles.hero}>
          <span style={styles.heroIcon}>❤️</span>
          <h1 style={styles.title}>CardioMonitor</h1>
          <p style={styles.subtitle}>
            Professional Cardiovascular Health Monitoring System
          </p>
          <p style={styles.description}>
            Real-time monitoring of your heart rate and respiratory health
            with advanced analytics and instant alerts.
          </p>

          <div style={styles.features}>
            <div style={styles.feature}>
              <span>📊</span>
              <p>Real-time Monitoring</p>
            </div>
            <div style={styles.feature}>
              <span>📈</span>
              <p>Advanced Analytics</p>
            </div>
            <div style={styles.feature}>
              <span>🚨</span>
              <p>Instant Alerts</p>
            </div>
          </div>

          <div style={styles.buttonContainer}>
            <Link to="/login">
              <button style={styles.buttonPrimary}>Login</button>
            </Link>

            <Link to="/register">
              <button style={styles.buttonSecondary}>Create Account</button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "linear-gradient(135deg, #f8f9fa 0%, #e8f4f8 100%)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "20px",
  },
  container: {
    maxWidth: "600px",
    width: "100%",
  },
  hero: {
    textAlign: "center",
    background: "white",
    padding: "60px 40px",
    borderRadius: "16px",
    boxShadow: "0 8px 32px rgba(0, 102, 204, 0.12)",
    animation: "slideUp 0.6s ease",
  },
  heroIcon: {
    fontSize: "80px",
    display: "block",
    marginBottom: "20px",
    animation: "pulse 2s infinite",
  },
  title: {
    fontSize: "3rem",
    fontWeight: "700",
    background: "linear-gradient(135deg, #0066cc 0%, #00d4ff 100%)",
    backgroundClip: "text",
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
    marginBottom: "12px",
    letterSpacing: "-1px",
  },
  subtitle: {
    fontSize: "1.1rem",
    color: "#6c757d",
    marginBottom: "16px",
    fontWeight: "500",
  },
  description: {
    fontSize: "1rem",
    color: "#6c757d",
    marginBottom: "40px",
    lineHeight: "1.8",
  },
  features: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr 1fr",
    gap: "20px",
    marginBottom: "40px",
  },
  feature: {
    padding: "20px",
    background: "#f8f9fa",
    borderRadius: "12px",
    border: "2px solid #e0e0e0",
    transition: "all 0.3s ease",
  },
  buttonContainer: {
    display: "flex",
    gap: "16px",
    justifyContent: "center",
    flexWrap: "wrap",
  },
  buttonPrimary: {
    background: "linear-gradient(135deg, #0066cc 0%, #00a8e8 100%)",
    color: "white",
    padding: "14px 40px",
    fontSize: "1rem",
    fontWeight: "600",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    transition: "all 0.3s ease",
    boxShadow: "0 4px 12px rgba(0, 102, 204, 0.3)",
    minWidth: "160px",
  },
  buttonSecondary: {
    background: "white",
    color: "#0066cc",
    padding: "14px 40px",
    fontSize: "1rem",
    fontWeight: "600",
    border: "2px solid #0066cc",
    borderRadius: "8px",
    cursor: "pointer",
    transition: "all 0.3s ease",
    minWidth: "160px",
  },
};

// Add animations
const animationStyles = `
  @keyframes slideUp {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
  
  @keyframes pulse {
    0%, 100% {
      transform: scale(1);
    }
    50% {
      transform: scale(1.05);
    }
  }

  button:hover {
    transform: translateY(-2px);
  }

  @media (max-width: 768px) {
    h1 {
      font-size: 2rem;
    }
    .feature {
      min-width: 100%;
    }
    .button-container {
      flex-direction: column;
    }
  }
`;

const styleSheet = document.createElement("style");
styleSheet.textContent = animationStyles;
document.head.appendChild(styleSheet);

export default Home;