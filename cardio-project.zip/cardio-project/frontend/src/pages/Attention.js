import React, { useEffect, useState } from "react";
import axios from "axios";
import Navbar from "../components/Navbar";

function Attention() {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchAlerts = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/health");

      const filtered = res.data.filter(
        (item) => item.status !== "Normal"
      );

      setAlerts(filtered);
      setLoading(false);
    } catch (err) {
      console.log(err);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlerts();
    const interval = setInterval(fetchAlerts, 5000);
    return () => clearInterval(interval);
  }, []);

  const getAlertLevel = (status) => {
    return status === "High Risk" ? "critical" : "warning";
  };

  const getAlertColor = (status) => {
    return status === "High Risk" ? "#e74c3c" : "#ff9800";
  };

  const getAlertIcon = (status) => {
    return status === "High Risk" ? "🚨" : "⚠️";
  };

  return (
    <div>
      <Navbar />

      <div style={styles.container}>
        <div style={styles.header}>
          <h1 style={styles.title}>🚨 Alert Monitor</h1>
          <p style={styles.subtitle}>Real-time abnormal reading detection</p>
        </div>

        <div style={styles.statsContainer}>
          <div style={styles.statCard}>
            <p style={styles.statLabel}>Total Alerts</p>
            <p style={styles.statValue}>{alerts.length}</p>
          </div>
          
          <div style={{...styles.statCard, borderLeft: `4px solid #e74c3c`}}>
            <p style={styles.statLabel}>High Risk</p>
            <p style={styles.statValue}>{alerts.filter(a => a.status === "High Risk").length}</p>
          </div>
          
          <div style={{...styles.statCard, borderLeft: `4px solid #ff9800`}}>
            <p style={styles.statLabel}>Low Risk</p>
            <p style={styles.statValue}>{alerts.filter(a => a.status === "Low Risk").length}</p>
          </div>
        </div>

        {alerts.length === 0 ? (
          <div style={styles.successCard}>
            <span style={styles.successIcon}>✅</span>
            <h2 style={styles.successTitle}>All Readings Normal</h2>
            <p style={styles.successMessage}>
              No abnormal readings detected. Your cardiovascular metrics are within healthy ranges.
            </p>
          </div>
        ) : (
          <div style={styles.alertsSection}>
            <div style={styles.alertsGrid}>
              {alerts.map((item) => (
                <div 
                  key={item._id} 
                  style={{
                    ...styles.alertCard,
                    borderLeft: `5px solid ${getAlertColor(item.status)}`,
                  }}
                >
                  <div style={styles.alertHeader}>
                    <span style={{...styles.alertIconLarge, color: getAlertColor(item.status)}}>
                      {getAlertIcon(item.status)}
                    </span>
                    <span style={{
                      ...styles.alertBadge,
                      background: getAlertColor(item.status),
                    }}>
                      {item.status}
                    </span>
                  </div>

                  <div style={styles.alertMetrics}>
                    <div style={styles.alertMetric}>
                      <p style={styles.alertMetricLabel}>Heart Rate</p>
                      <p style={styles.alertMetricValue}>{item.heartRate} bpm</p>
                    </div>
                    
                    <div style={styles.alertMetric}>
                      <p style={styles.alertMetricLabel}>Respiratory Rate</p>
                      <p style={styles.alertMetricValue}>{item.respiratoryRate} /min</p>
                    </div>
                  </div>

                  <div style={styles.alertFooter}>
                    <span style={styles.alertTime}>
                      ⏰ {new Date(item.createdAt).toLocaleString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

const styles = {
  container: {
    maxWidth: "1200px",
    margin: "0 auto",
    padding: "40px 20px",
  },
  header: {
    marginBottom: "40px",
    textAlign: "center",
  },
  title: {
    fontSize: "2.5rem",
    color: "#e74c3c",
    marginBottom: "8px",
  },
  subtitle: {
    fontSize: "1.1rem",
    color: "#6c757d",
  },
  statsContainer: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
    gap: "20px",
    marginBottom: "40px",
  },
  statCard: {
    background: "white",
    borderRadius: "12px",
    padding: "24px",
    textAlign: "center",
    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.08)",
    border: "2px solid #e0e0e0",
  },
  statLabel: {
    color: "#6c757d",
    fontSize: "0.95rem",
    margin: "0 0 8px 0",
  },
  statValue: {
    fontSize: "2rem",
    fontWeight: "700",
    color: "#0066cc",
    margin: 0,
  },
  successCard: {
    background: "linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%)",
    border: "2px solid #c3e6cb",
    borderRadius: "16px",
    padding: "60px 40px",
    textAlign: "center",
    marginBottom: "40px",
  },
  successIcon: {
    fontSize: "64px",
    display: "block",
    marginBottom: "16px",
    animation: "bounce 1s infinite",
  },
  successTitle: {
    color: "#155724",
    fontSize: "1.8rem",
    marginBottom: "12px",
  },
  successMessage: {
    color: "#155724",
    fontSize: "1.05rem",
  },
  alertsSection: {
    marginTop: "40px",
  },
  alertsGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))",
    gap: "20px",
  },
  alertCard: {
    background: "white",
    borderRadius: "12px",
    padding: "24px",
    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
    transition: "all 0.3s ease",
  },
  alertHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "16px",
    paddingBottom: "12px",
    borderBottom: "2px solid #e0e0e0",
  },
  alertIconLarge: {
    fontSize: "32px",
  },
  alertBadge: {
    color: "white",
    padding: "6px 14px",
    borderRadius: "20px",
    fontSize: "0.85rem",
    fontWeight: "600",
  },
  alertMetrics: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: "12px",
    marginBottom: "16px",
  },
  alertMetric: {
    padding: "12px",
    background: "#f8f9fa",
    borderRadius: "8px",
  },
  alertMetricLabel: {
    fontSize: "0.8rem",
    color: "#6c757d",
    margin: "0 0 4px 0",
  },
  alertMetricValue: {
    fontSize: "1.3rem",
    fontWeight: "700",
    color: "#333",
    margin: 0,
  },
  alertFooter: {
    borderTop: "2px solid #e0e0e0",
    paddingTop: "12px",
  },
  alertTime: {
    fontSize: "0.85rem",
    color: "#6c757d",
  },
};

const animationStyles = `
  @keyframes bounce {
    0%, 100% {
      transform: scale(1);
    }
    50% {
      transform: scale(1.1);
    }
  }

  @media (max-width: 768px) {
    .title {
      font-size: 1.8rem;
    }
    
    .success-icon {
      font-size: 48px;
    }
    
    .alerts-grid {
      grid-template-columns: 1fr;
    }
  }

  .alert-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 12px 28px rgba(0, 0, 0, 0.15);
  }
`;

const styleSheet = document.createElement("style");
styleSheet.textContent = animationStyles;
document.head.appendChild(styleSheet);

export default Attention;