import React, { useEffect, useState } from "react";
import axios from "axios";
import Navbar from "../components/Navbar";

function Dashboard() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/health");
      setData(res.data);
      setLoading(false);
    } catch (err) {
      console.log(err);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  const latest = data[0];

  const getStatusColor = (status) => {
    switch (status) {
      case "High Risk":
        return "#e74c3c";
      case "Low Risk":
        return "#ff9800";
      default:
        return "#00b894";
    }
  };

  return (
    <div>
      <Navbar />

      <div style={styles.container}>
        <div style={styles.header}>
          <h1 style={styles.pageTitle}>📊 Dashboard</h1>
          <p style={styles.subtitle}>Monitor your cardiovascular health in real-time</p>
        </div>

        {latest ? (
          <div style={styles.latestCard}>
            <div style={styles.latestHeader}>
              <h2 style={styles.cardTitle}>Latest Reading</h2>
              <span style={{
                ...styles.statusBadge,
                background: getStatusColor(latest.status),
              }}>
                {latest.status}
              </span>
            </div>
            
            <div style={styles.metricsGrid}>
              <div style={styles.metric}>
                <div style={styles.metricIcon}>❤️</div>
                <div style={styles.metricInfo}>
                  <p style={styles.metricLabel}>Heart Rate</p>
                  <p style={styles.metricValue}>{latest.heartRate} bpm</p>
                </div>
              </div>
              
              <div style={styles.metric}>
                <div style={styles.metricIcon}>🌬️</div>
                <div style={styles.metricInfo}>
                  <p style={styles.metricLabel}>Respiratory Rate</p>
                  <p style={styles.metricValue}>{latest.respiratoryRate} /min</p>
                </div>
              </div>
              
              <div style={styles.metric}>
                <div style={styles.metricIcon}>⏰</div>
                <div style={styles.metricInfo}>
                  <p style={styles.metricLabel}>Last Updated</p>
                  <p style={styles.metricValue}>{new Date(latest.createdAt).toLocaleTimeString()}</p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div style={styles.emptyState}>
            <p>No data available. Waiting for sensor readings...</p>
          </div>
        )}

        <div style={styles.historySection}>
          <h2 style={styles.sectionTitle}>📈 Reading History</h2>
          
          {data.length === 0 ? (
            <div style={styles.emptyState}>
              <p>No historical data available yet</p>
            </div>
          ) : (
            <div style={styles.tableWrapper}>
              <table style={styles.table}>
                <thead>
                  <tr>
                    <th>Heart Rate</th>
                    <th>Respiratory</th>
                    <th>Status</th>
                    <th>Timestamp</th>
                  </tr>
                </thead>
                <tbody>
                  {data.map((item) => (
                    <tr key={item._id} style={styles.tableRow}>
                      <td style={styles.tableCell}><span style={styles.badge}>❤️ {item.heartRate} bpm</span></td>
                      <td style={styles.tableCell}><span style={styles.badge}>🌬️ {item.respiratoryRate} /min</span></td>
                      <td style={styles.tableCell}>
                        <span style={{
                          ...styles.statusBadge,
                          background: getStatusColor(item.status),
                          fontSize: "0.85rem",
                          padding: "4px 12px",
                        }}>
                          {item.status}
                        </span>
                      </td>
                      <td style={styles.tableCell}>{new Date(item.createdAt).toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

const styles = {
  container: {
    maxWidth: "1200px",
    margin: "0 auto",
    padding: "40px 20px",
  },
  header: {
    marginBottom: "40px",
    textAlign: "center",
  },
  pageTitle: {
    fontSize: "2.5rem",
    color: "#0066cc",
    marginBottom: "8px",
  },
  subtitle: {
    fontSize: "1.1rem",
    color: "#6c757d",
  },
  latestCard: {
    background: "white",
    borderRadius: "16px",
    padding: "32px",
    marginBottom: "40px",
    boxShadow: "0 8px 24px rgba(0, 0, 0, 0.1)",
    border: "2px solid #e0e0e0",
    transition: "all 0.3s ease",
  },
  latestHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "24px",
    paddingBottom: "16px",
    borderBottom: "2px solid #e0e0e0",
  },
  cardTitle: {
    fontSize: "1.5rem",
    margin: 0,
    color: "#333",
  },
  statusBadge: {
    color: "white",
    padding: "8px 16px",
    borderRadius: "20px",
    fontWeight: "600",
    fontSize: "0.9rem",
  },
  metricsGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
    gap: "20px",
  },
  metric: {
    display: "flex",
    alignItems: "center",
    gap: "16px",
    padding: "20px",
    background: "#f8f9fa",
    borderRadius: "12px",
    border: "2px solid #e0e0e0",
    transition: "all 0.3s ease",
  },
  metricIcon: {
    fontSize: "40px",
  },
  metricInfo: {
    flex: 1,
  },
  metricLabel: {
    fontSize: "0.9rem",
    color: "#6c757d",
    margin: "0 0 4px 0",
  },
  metricValue: {
    fontSize: "1.5rem",
    fontWeight: "700",
    color: "#0066cc",
    margin: 0,
  },
  historySection: {
    marginTop: "40px",
  },
  sectionTitle: {
    fontSize: "1.8rem",
    color: "#333",
    marginBottom: "24px",
  },
  tableWrapper: {
    background: "white",
    borderRadius: "12px",
    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.08)",
    overflow: "hidden",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
  },
  tableRow: {
    transition: "background-color 0.3s ease",
  },
  tableCell: {
    padding: "16px",
    textAlign: "left",
  },
  badge: {
    display: "inline-block",
    padding: "6px 12px",
    background: "#e8f4f8",
    borderRadius: "6px",
    fontSize: "0.9rem",
    fontWeight: "500",
    color: "#0066cc",
  },
  emptyState: {
    textAlign: "center",
    padding: "40px",
    background: "white",
    borderRadius: "12px",
    color: "#6c757d",
  },
};

const animationStyles = `
  @media (max-width: 768px) {
    .page-title {
      font-size: 1.8rem;
    }
    
    .latest-card {
      padding: 20px;
    }
    
    .metrics-grid {
      grid-template-columns: 1fr;
    }
    
    .table-cell {
      padding: 12px 8px;
      font-size: 0.85rem;
    }
  }

  .metric:hover {
    background-color: #f0f8ff;
    transform: translateY(-2px);
  }

  tbody tr:hover {
    background-color: #f8f9fa;
  }
`;

const styleSheet = document.createElement("style");
styleSheet.textContent = animationStyles;
document.head.appendChild(styleSheet);

export default Dashboard;