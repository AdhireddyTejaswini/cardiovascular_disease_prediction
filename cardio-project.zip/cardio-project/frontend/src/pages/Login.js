import React, { useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

function Login() {
  const [form, setForm] = useState({
    email: "",
    password: "",
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await axios.post(
        "http://localhost:5000/api/users/login",
        form
      );

      alert(res.data.message);
      window.location.href = "/dashboard";

    } catch (err) {
      alert("Invalid credentials");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <div style={styles.card}>
          <div style={styles.header}>
            <span style={styles.icon}>🔐</span>
            <h2>Welcome Back</h2>
            <p style={styles.subtitle}>Login to your account</p>
          </div>

          <form onSubmit={handleSubmit} style={styles.form}>
            <div style={styles.formGroup}>
              <label style={styles.label}>Email Address</label>
              <input 
                type="email" 
                name="email" 
                placeholder="your@email.com"
                value={form.email}
                onChange={handleChange}
                required 
                style={styles.input}
              />
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>Password</label>
              <input 
                type="password" 
                name="password" 
                placeholder="••••••••"
                value={form.password}
                onChange={handleChange}
                required 
                style={styles.input}
              />
            </div>

            <button 
              type="submit" 
              style={{
                ...styles.button,
                opacity: loading ? 0.7 : 1,
                cursor: loading ? "not-allowed" : "pointer"
              }}
              disabled={loading}
            >
              {loading ? "Logging in..." : "Login"}
            </button>
          </form>

          <div style={styles.footer}>
            <p>Don't have an account? <Link to="/register" style={styles.link}>Create one</Link></p>
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "linear-gradient(135deg, #0066cc 0%, #00d4ff 100%)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "20px",
  },
  container: {
    maxWidth: "420px",
    width: "100%",
  },
  card: {
    background: "white",
    borderRadius: "16px",
    boxShadow: "0 20px 60px rgba(0, 0, 0, 0.2)",
    overflow: "hidden",
    animation: "slideIn 0.5s ease",
  },
  header: {
    background: "linear-gradient(135deg, #0066cc 0%, #00a8e8 100%)",
    color: "white",
    padding: "40px 20px",
    textAlign: "center",
  },
  icon: {
    fontSize: "48px",
    display: "block",
    marginBottom: "16px",
  },
  subtitle: {
    margin: "8px 0 0 0",
    fontSize: "0.95rem",
    opacity: 0.9,
  },
  form: {
    padding: "40px",
  },
  formGroup: {
    marginBottom: "24px",
  },
  label: {
    display: "block",
    marginBottom: "8px",
    fontWeight: "600",
    color: "#333",
    fontSize: "0.95rem",
  },
  input: {
    width: "100%",
    padding: "12px 16px",
    border: "2px solid #e0e0e0",
    borderRadius: "8px",
    fontSize: "1rem",
    fontFamily: "inherit",
    transition: "all 0.3s ease",
    backgroundColor: "#f8f9fa",
  },
  button: {
    width: "100%",
    padding: "14px",
    background: "linear-gradient(135deg, #0066cc 0%, #00a8e8 100%)",
    color: "white",
    fontSize: "1rem",
    fontWeight: "600",
    border: "none",
    borderRadius: "8px",
    cursor: "pointer",
    transition: "all 0.3s ease",
    boxShadow: "0 4px 12px rgba(0, 102, 204, 0.3)",
  },
  footer: {
    padding: "20px 40px",
    textAlign: "center",
    borderTop: "1px solid #e0e0e0",
    color: "#666",
    fontSize: "0.95rem",
  },
  link: {
    color: "#0066cc",
    fontWeight: "600",
    textDecoration: "none",
  },
};

const animationStyles = `
  @keyframes slideIn {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  input:focus {
    background-color: white;
    border-color: #0066cc;
    box-shadow: 0 0 0 3px rgba(0, 102, 204, 0.1);
  }

  button:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(0, 102, 204, 0.4);
  }
`;

const styleSheet = document.createElement("style");
styleSheet.textContent = animationStyles;
document.head.appendChild(styleSheet);

export default Login;